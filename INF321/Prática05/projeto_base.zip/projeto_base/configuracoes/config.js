const config = {
    db: 'usuarios.db3',
    title: 'Gestão de Usuários Fullstack'
};

module.exports = config;
